<?php
include 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM produk WHERE id=$id");
$row = mysqli_fetch_assoc($data);

if (isset($_POST['edit'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    mysqli_query($conn, "UPDATE produk SET nama='$nama', harga='$harga' WHERE id=$id");
    header("Location: dashboard.php");
}
?>

<form method="POST">
    Nama: <input type="text" name="nama" value="<?= $row['nama'] ?>"><br>
    Harga: <input type="number" name="harga" value="<?= $row['harga'] ?>"><br>
    <button name="edit">Simpan</button>
</form>