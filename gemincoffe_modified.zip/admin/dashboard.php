<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit();
}
include 'koneksi.php';
?>

<a href="tambah.php">Tambah Produk</a> | <a href="logout.php">Logout</a>

<h2>Daftar Menu</h2>
<table border="1">
<tr><th>No</th><th>Nama</th><th>Harga</th><th>Aksi</th></tr>
<?php
$no = 1;
$data = mysqli_query($conn, "SELECT * FROM produk");
while ($row = mysqli_fetch_assoc($data)) {
    echo "<tr>
        <td>$no</td>
        <td>{$row['nama']}</td>
        <td>{$row['harga']}</td>
        <td>
            <a href='edit.php?id={$row['id']}'>Edit</a> |
            <a href='hapus.php?id={$row['id']}'>Hapus</a>
        </td>
    </tr>";
    $no++;
}
?>
</table>