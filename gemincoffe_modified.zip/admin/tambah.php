<?php
include 'koneksi.php';
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    mysqli_query($conn, "INSERT INTO produk (nama, harga) VALUES ('$nama', '$harga')");
    header("Location: dashboard.php");
}
?>

<form method="POST">
    Nama Produk: <input type="text" name="nama"><br>
    Harga: <input type="number" name="harga"><br>
    <button name="tambah">Tambah</button>
</form>