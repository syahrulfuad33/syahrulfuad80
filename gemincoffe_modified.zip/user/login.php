<?php
session_start();
include '../admin/koneksi.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    $data = mysqli_fetch_assoc($query);

    if ($data && password_verify($password, $data['password'])) {
        $_SESSION['user'] = $data;
        header("Location: home.php");
    } else {
        echo "Login gagal!";
    }
}
?>

<form method="POST">
    <h2>Login Pengguna</h2>
    Email: <input type="email" name="email"><br>
    Password: <input type="password" name="password"><br>
    <button type="submit" name="login">Login</button>
    <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
</form>