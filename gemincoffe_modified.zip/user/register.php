<?php
include '../admin/koneksi.php';

if (isset($_POST['daftar'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($check) > 0) {
        echo "Email sudah terdaftar!";
    } else {
        mysqli_query($conn, "INSERT INTO users (nama, email, password) VALUES ('$nama', '$email', '$password')");
        echo "Pendaftaran berhasil! <a href='login.php'>Login sekarang</a>";
    }
}
?>

<form method="POST">
    <h2>Daftar Pengguna</h2>
    Nama: <input type="text" name="nama"><br>
    Email: <input type="email" name="email"><br>
    Password: <input type="password" name="password"><br>
    <button name="daftar">Daftar</button>
</form>