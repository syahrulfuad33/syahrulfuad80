<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
$user = $_SESSION['user'];
?>
<h2>Selamat datang, <?= $user['nama'] ?>!</h2>
<p>Anda berhasil login sebagai pengguna.</p>
<a href="logout.php">Logout</a>